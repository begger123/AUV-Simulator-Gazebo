to import the models-
move the content of this folder to ~/.gazebo/models
